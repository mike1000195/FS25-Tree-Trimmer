TreeTrimmer = {}
TreeTrimmer.MOD_NAME = g_currentModName
TreeTrimmer.DEFAULT_STEP = 0.10
TreeTrimmer.DEFAULT_MAX_PASSES = 12
TreeTrimmer.DEBUG_PREFIX = "[FS25_TreeTrimmer R18]"

local function ttLog(fmt, ...)
    local msg = string.format(fmt, ...)
    print(string.format("%s %s", TreeTrimmer.DEBUG_PREFIX, msg))
end

local function vecMul(x, y, z, s)
    return x * s, y * s, z * s
end

local function vecAdd(ax, ay, az, bx, by, bz)
    return ax + bx, ay + by, az + bz
end

local function vecSub(ax, ay, az, bx, by, bz)
    return ax - bx, ay - by, az - bz
end

local function vecLen(x, y, z)
    return math.sqrt(x * x + y * y + z * z)
end

local function vecNormalize(x, y, z)
    local len = vecLen(x, y, z)
    if len < 0.0001 then
        return 0, 1, 0, 0
    end
    return x / len, y / len, z / len, len
end

-- ==========================================================================
-- Network Event: synchronizes trim operations across server and all clients
-- ==========================================================================

TreeTrimmerEvent = {}
local TreeTrimmerEvent_mt = Class(TreeTrimmerEvent, Event)
InitEventClass(TreeTrimmerEvent, "TreeTrimmerEvent")

function TreeTrimmerEvent.emptyNew()
    return Event.new(TreeTrimmerEvent_mt)
end

function TreeTrimmerEvent.new(treeNode, stepSize, maxPasses)
    local self = TreeTrimmerEvent.emptyNew()
    self.treeNode = treeNode
    self.stepSize = stepSize or TreeTrimmer.DEFAULT_STEP
    self.maxPasses = maxPasses or TreeTrimmer.DEFAULT_MAX_PASSES
    return self
end

function TreeTrimmerEvent:readStream(streamId, connection)
    self.treeNode = readSplitShapeIdFromStream(streamId)
    self.stepSize = streamReadFloat32(streamId)
    self.maxPasses = streamReadInt32(streamId)
    self:run(connection)
end

function TreeTrimmerEvent:writeStream(streamId, connection)
    writeSplitShapeIdToStream(streamId, self.treeNode or 0)
    streamWriteFloat32(streamId, self.stepSize)
    streamWriteInt32(streamId, self.maxPasses)
end

function TreeTrimmerEvent:run(connection)
    if self.treeNode == nil or not entityExists(self.treeNode) then
        ttLog("Event: tree node invalid or missing, skipping")
        return
    end

    -- Execute the trim locally on this machine
    TreeTrimmer.executeTrimOnNode(self.treeNode, self.stepSize, self.maxPasses)

    -- If this event arrived at the server from a client, rebroadcast to all
    -- other clients so every machine stays in sync.
    -- The third arg excludes the sending connection so the originating client
    -- (who already received the broadcast) doesn't get a duplicate.
    -- If this event arrived at the server from a client, rebroadcast to ALL
    -- clients (including the sender) so every machine executes the trim.
    if not connection:getIsServer() then
        ttLog("Event: server rebroadcasting trim to all clients")
        g_server:broadcastEvent(TreeTrimmerEvent.new(self.treeNode, self.stepSize, self.maxPasses))
    end
end

-- ==========================================================================
-- Core trim logic (no network, no handTool dependency — works on any machine)
-- ==========================================================================

function TreeTrimmer.getAttachmentCount(node)
    if node == nil or node == 0 or not entityExists(node) or getSplitType(node) == 0 then
        return nil
    end

    local _, _, _, _, numAttachments = getSplitShapeStats(node)
    return numAttachments
end

function TreeTrimmer.getTreeAxes(node)
    local isStandingTree = getRigidBodyType(node) == RigidBodyType.STATIC

    local axisX, axisY, axisZ
    local upX, upY, upZ
    local sideX, sideY, sideZ

    if isStandingTree then
        axisX, axisY, axisZ = localDirectionToWorld(node, 0, 1, 0)
        upX, upY, upZ = localDirectionToWorld(node, 1, 0, 0)
        sideX, sideY, sideZ = localDirectionToWorld(node, 0, 0, -1)
    else
        axisX, axisY, axisZ = localDirectionToWorld(node, 1, 0, 0)
        upX, upY, upZ = localDirectionToWorld(node, 0, 1, 0)
        sideX, sideY, sideZ = localDirectionToWorld(node, 0, 0, -1)
    end

    axisX, axisY, axisZ = vecNormalize(axisX, axisY, axisZ)
    upX, upY, upZ = vecNormalize(upX, upY, upZ)
    sideX, sideY, sideZ = vecNormalize(sideX, sideY, sideZ)

    return axisX, axisY, axisZ, upX, upY, upZ, sideX, sideY, sideZ, isStandingTree
end

--- Performs the actual attachment removal on a tree node.
--- Called on every machine (server + all clients) independently so that
--- each machine's local split shape geometry stays consistent.
function TreeTrimmer.executeTrimOnNode(treeNode, stepSize, maxPasses)
    local before = TreeTrimmer.getAttachmentCount(treeNode)
    if before == nil or before <= 0 then
        ttLog("executeTrimOnNode: node %s has no attachments, nothing to do", tostring(treeNode))
        return true, 0, before or 0
    end

    stepSize = math.max(stepSize or TreeTrimmer.DEFAULT_STEP, 0.05)
    maxPasses = math.max(maxPasses or TreeTrimmer.DEFAULT_MAX_PASSES, 1)

    local sizeX, sizeY, sizeZ = getSplitShapeStats(treeNode)
    local length = math.max(sizeX or 0, sizeY or 0, sizeZ or 0)
    if length <= 0.01 then
        return false, 0, before
    end

    local axisX, axisY, axisZ, upX, upY, upZ, sideX, sideY, sideZ = TreeTrimmer.getTreeAxes(treeNode)
    local centerX, centerY, centerZ = getWorldTranslation(treeNode)
    local halfLength = length * 0.5

    local planeWidth = 64.0
    local planeDepth = 64.0
    local searchRadius = 14.0
    local tipOvershoot = 3.0

    local startX, startY, startZ = vecSub(centerX, centerY, centerZ, vecMul(axisX, axisY, axisZ, halfLength + tipOvershoot))
    local endX, endY, endZ = vecAdd(centerX, centerY, centerZ, vecMul(axisX, axisY, axisZ, halfLength + tipOvershoot))
    local spanX, spanY, spanZ = vecSub(endX, endY, endZ, startX, startY, startZ)
    local spanLength = vecLen(spanX, spanY, spanZ)
    local steps = math.max(1, math.ceil(spanLength / stepSize))

    local removedAny = false

    for passIndex = 1, maxPasses do
        local removedThisPass = false

        local offsetDistances = {0, searchRadius * 0.50, -searchRadius * 0.50, searchRadius, -searchRadius, searchRadius * 1.50, -searchRadius * 1.50}

        for i = 0, steps do
            local t = i / steps
            local baseX = startX + spanX * t
            local baseY = startY + spanY * t
            local baseZ = startZ + spanZ * t

            for _, upOffset in ipairs(offsetDistances) do
                for _, sideOffset in ipairs(offsetDistances) do
                    local posX = baseX + upX * upOffset + sideX * sideOffset
                    local posY = baseY + upY * upOffset + sideY * sideOffset
                    local posZ = baseZ + upZ * upOffset + sideZ * sideOffset

                    local removedAttachment = removeSplitShapeAttachments(treeNode, posX, posY, posZ, axisX, axisY, axisZ, upX, upY, upZ, searchRadius, planeWidth, planeDepth)
                    if removedAttachment then
                        removedThisPass = true
                        removedAny = true
                    end

                    removedAttachment = removeSplitShapeAttachments(treeNode, posX, posY, posZ, axisX, axisY, axisZ, sideX, sideY, sideZ, searchRadius, planeWidth, planeDepth)
                    if removedAttachment then
                        removedThisPass = true
                        removedAny = true
                    end
                end
            end
        end

        local remaining = TreeTrimmer.getAttachmentCount(treeNode) or 0
        if not removedThisPass or remaining <= 0 then
            break
        end
    end

    local after = TreeTrimmer.getAttachmentCount(treeNode) or 0
    local removedCount = math.max(before - after, 0)

    ttLog("executeTrimOnNode: tree %s removed=%d remaining=%d length=%.2f steps=%d",
        tostring(treeNode), removedCount, after, length, steps)

    return removedAny, removedCount, after
end

-- ==========================================================================
-- Network-aware entry point (called by the player who initiates the trim)
-- ==========================================================================

function TreeTrimmer.trimWholeTree(handTool)
    local treeNode = TreeTrimmer.getTargetedTreeNode(handTool)
    if treeNode == nil then
        return false, 0, 0
    end

    local before = TreeTrimmer.getAttachmentCount(treeNode)
    if before == nil or before <= 0 then
        return true, 0, before or 0
    end

    local spec = handTool.spec_treeTrimmer or {}
    local stepSize = math.max(spec.stepSize or TreeTrimmer.DEFAULT_STEP, 0.05)
    local maxPasses = math.max(spec.maxPasses or TreeTrimmer.DEFAULT_MAX_PASSES, 1)

    if g_server ~= nil then
        -- We ARE the server: execute locally and broadcast to all clients
        local removedAny, removedCount, after = TreeTrimmer.executeTrimOnNode(treeNode, stepSize, maxPasses)
        g_server:broadcastEvent(TreeTrimmerEvent.new(treeNode, stepSize, maxPasses))

        if removedAny then
            TreeTrimmer.triggerChainsawEffects(handTool)
        end

        return removedAny, removedCount, after
    else
        -- We are a client: send request to server, do NOT execute locally.
        -- The server will execute and broadcast back to us (and all other
        -- clients) via the event's run() method.
        ttLog("trimWholeTree: client sending trim request to server")
        g_client:getServerConnection():sendEvent(TreeTrimmerEvent.new(treeNode, stepSize, maxPasses))

        -- Trigger local cosmetic effects immediately for responsiveness
        TreeTrimmer.triggerChainsawEffects(handTool)

        return true, 0, before
    end
end

--- Fire the chainsaw particle/sound effects so the player gets feedback.
--- This is cosmetic only and does not affect split shape state.
function TreeTrimmer.triggerChainsawEffects(handTool)
    local chainsawSpec = handTool.spec_chainsaw
    if chainsawSpec ~= nil then
        chainsawSpec.effectEndTime = g_time + 500
    end
end

-- ==========================================================================
-- Chainsaw hook helpers
-- ==========================================================================

function TreeTrimmer.registerXMLPaths(xmlSchema)
    xmlSchema:setXMLSpecializationType("TreeTrimmer")
    xmlSchema:register(XMLValueType.BOOL, "handTool.treeTrimmer#enabled", "Whether the custom one-click tree trimmer behavior is enabled", false)
    xmlSchema:register(XMLValueType.FLOAT, "handTool.treeTrimmer#stepSize", "Distance between trim passes along the targeted tree", TreeTrimmer.DEFAULT_STEP)
    xmlSchema:register(XMLValueType.INT, "handTool.treeTrimmer#maxPasses", "Maximum attachment-removal sweep passes", TreeTrimmer.DEFAULT_MAX_PASSES)
    xmlSchema:register(XMLValueType.NODE_INDEX, "handTool.treeTrimmer.pivotNode#node", "Transform group to rotate for swing animation")
    xmlSchema:register(XMLValueType.FLOAT, "handTool.treeTrimmer#chopRange", "Swing animation range in radians", 0.5)
    xmlSchema:register(XMLValueType.FLOAT, "handTool.treeTrimmer#chopSpeed", "Swing animation speed multiplier", 0.01)
    xmlSchema:setXMLSpecializationType()
end

function TreeTrimmer.onLoad(handTool, xmlFile)
    handTool.spec_treeTrimmer = handTool.spec_treeTrimmer or {}
    local spec = handTool.spec_treeTrimmer
    spec.enabled = xmlFile:getValue("handTool.treeTrimmer#enabled", false)
    spec.stepSize = xmlFile:getValue("handTool.treeTrimmer#stepSize", TreeTrimmer.DEFAULT_STEP)
    spec.maxPasses = xmlFile:getValue("handTool.treeTrimmer#maxPasses", TreeTrimmer.DEFAULT_MAX_PASSES)
    spec.trimText = "Trim tree branches"
    spec.pivotNode = xmlFile:getValue("handTool.treeTrimmer.pivotNode#node", nil, handTool.components, handTool.i3dMappings)
    spec.chopRange = xmlFile:getValue("handTool.treeTrimmer#chopRange", 0.5)
    spec.chopSpeed = xmlFile:getValue("handTool.treeTrimmer#chopSpeed", 0.01)

    if spec.pivotNode ~= nil then
        spec.pivotRestRX, spec.pivotRestRY, spec.pivotRestRZ = getRotation(spec.pivotNode)
    end
end

function TreeTrimmer.getTargetedTreeNode(handTool)
    local spec = handTool.spec_chainsaw
    if spec == nil then
        return nil
    end

    local targetedTree = spec.targetedTree
    if targetedTree ~= nil and targetedTree.node ~= nil and targetedTree.node ~= 0 and entityExists(targetedTree.node) then
        return targetedTree.node
    end

    return nil
end

-- ==========================================================================
-- Overwritten chainsaw hooks
-- ==========================================================================

function TreeTrimmer.onCutAction(handTool, superFunc, _, inputValue)
    local trimmerSpec = handTool.spec_treeTrimmer
    if trimmerSpec == nil or not trimmerSpec.enabled then
        return superFunc(handTool, _, inputValue)
    end

    local isInputDown = inputValue > 0
    local chainsawSpec = handTool.spec_chainsaw
    if chainsawSpec == nil then
        return superFunc(handTool, _, inputValue)
    end

    chainsawSpec.isCutting = isInputDown

    if not isInputDown then
        if chainsawSpec.currentCutState == ChainsawCutState.DELIMBING then
            handTool:stopDelimbing()
        else
            chainsawSpec.currentCutState = ChainsawCutState.IDLE
        end
        return
    end

    local treeNode = TreeTrimmer.getTargetedTreeNode(handTool)
    if treeNode ~= nil then
        if chainsawSpec.currentCutState ~= ChainsawCutState.DELIMBING then
            handTool:beginDelimbing()
        end

        TreeTrimmer.trimWholeTree(handTool)
        return
    end

    if chainsawSpec.currentCutState == ChainsawCutState.DELIMBING then
        handTool:stopDelimbing()
    else
        chainsawSpec.currentCutState = ChainsawCutState.IDLE
    end
end

function TreeTrimmer.onUpdate(handTool, superFunc, dt)
    superFunc(handTool, dt)

    local trimmerSpec = handTool.spec_treeTrimmer
    if trimmerSpec == nil or not trimmerSpec.enabled then
        return
    end

    local carryingPlayer = handTool:getCarryingPlayer()
    if carryingPlayer == nil or not carryingPlayer.isOwner or not handTool:getIsHeld() then
        return
    end

    local chainsawSpec = handTool.spec_chainsaw
    if chainsawSpec == nil then
        return
    end

    -- Swing animation: rotate the pivot node (swingNode is reparented under it)
    if trimmerSpec.pivotNode ~= nil and trimmerSpec.pivotRestRX ~= nil then
        if chainsawSpec.isCutting then
            local angle = math.sin(g_time * trimmerSpec.chopSpeed) * trimmerSpec.chopRange
            setRotation(trimmerSpec.pivotNode, trimmerSpec.pivotRestRX + angle, trimmerSpec.pivotRestRY, trimmerSpec.pivotRestRZ)
        else
            local curRX = getRotation(trimmerSpec.pivotNode)
            if math.abs(curRX - trimmerSpec.pivotRestRX) > 0.001 then
                setRotation(trimmerSpec.pivotNode, trimmerSpec.pivotRestRX, trimmerSpec.pivotRestRY, trimmerSpec.pivotRestRZ)
            end
        end
    end

    if chainsawSpec.currentCutState == ChainsawCutState.IDLE and chainsawSpec.activateActionId ~= nil then
        local treeNode = TreeTrimmer.getTargetedTreeNode(handTool)
        if treeNode ~= nil then
            g_inputBinding:setActionEventText(chainsawSpec.activateActionId, trimmerSpec.trimText)
            g_inputBinding:setActionEventTextVisibility(chainsawSpec.activateActionId, true)
        end
    end
end

-- ==========================================================================
-- Hook registration
-- ==========================================================================

HandToolChainsaw.registerXMLPaths = Utils.appendedFunction(HandToolChainsaw.registerXMLPaths, TreeTrimmer.registerXMLPaths)
HandToolChainsaw.onLoad = Utils.appendedFunction(HandToolChainsaw.onLoad, TreeTrimmer.onLoad)
HandToolChainsaw.onCutAction = Utils.overwrittenFunction(HandToolChainsaw.onCutAction, TreeTrimmer.onCutAction)
HandToolChainsaw.onUpdate = Utils.overwrittenFunction(HandToolChainsaw.onUpdate, TreeTrimmer.onUpdate)
